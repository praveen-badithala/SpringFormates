package com.example.springhellojsp.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.springhellojsp.entity.EmployeeEntity;

public class Test {
public static void main(String[] args) {
	//comparable example
	List<Car> emplist=new ArrayList<Car>();
	Car emp1=new Car();
	Car emp2=new Car();
	Car emp3=new Car();
	
	emp1.setCarNO(1);
	emp2.setCarNO(1);
	emp1.setCarName("rr");
	emp3.setCarNO(3);
	emp2.setCarName("rr");
	
	
	emplist.add(emp3);
	emplist.add(emp2);
	emplist.add(emp1);
	Collections.sort(emplist);
	System.out.println(emplist.size());
	System.out.println("===========================");
	
	
	//comparator examp
	List<EmployeeEntity> list=new ArrayList();
	EmployeeEntity e1=new EmployeeEntity();
	EmployeeEntity e2=new EmployeeEntity();
	EmployeeEntity e3=new EmployeeEntity();
	EmployeeEntity e4=new EmployeeEntity();
	EmployeeEntity e5=new EmployeeEntity();
	e1.setEmpID(1);
	e2.setEmpID(2);
	e3.setEmpID(3);
	e4.setEmpID(4);
	e5.setEmpID(5);
	
	list.add(e3);
	list.add(e1);
	list.add(e2);
	list.add(e5);
	list.add(e4);
	Collections.sort(list, new EmployeeComparator());
	for(EmployeeEntity entity:list) {
	   System.out.println(entity.getEmpID());
	
	}
	
	//checking object as duplicate keys in hashmap
	
	Map<Car,String> map=new HashMap<Car,String>();
	map.put(emp1,"mahesh");
	map.put(emp2,"mahesh");
	map.put(emp3,"mahesh");
	
	System.out.println("65>>>>>>>"+map.size());
	
}
}
