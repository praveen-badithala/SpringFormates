package com.example.springhellojsp.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.springhellojsp.entity.DepartMent;
import com.example.springhellojsp.entity.EmployeeEntity;

@Repository
@Transactional
public class EmployeeDao {
 
	@Autowired
	private SessionFactory sessionfactory;
	
	public void saveEmp(EmployeeEntity emp) {
		sessionfactory.getCurrentSession().saveOrUpdate(emp);
		
		//System.out.println(sessionfactory.getCurrentSession().get(EmployeeEntity.class,10).getLanguages()[0]);
	}
	
	public List<DepartMent> loaddepartmentlist(String deptname){
		
		if(deptname!=null && deptname!="") {
			return sessionfactory.getCurrentSession().createQuery("FROM DepartMent WHERE departmentName like '%"+deptname+"%' ",DepartMent.class).list();
		}else {
			return sessionfactory.getCurrentSession().createQuery("FROM DepartMent ",DepartMent.class).list();
		}
	}
	
	public List<EmployeeEntity> getemplist(){
		return sessionfactory.getCurrentSession().createQuery("FROM EmployeeEntity ORDER BY empName",EmployeeEntity.class).list();
	}
	
	public EmployeeEntity loadById(int empid) {
		return sessionfactory.getCurrentSession().get(EmployeeEntity.class,empid);
		
	}
	
}
