package com.example.springhellojsp.validator;

import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import com.example.springhellojsp.model.EmployeeModel;
@Component
public class EmployeeValidator implements org.springframework.validation.Validator {

	
	@Override
	public boolean supports(Class<?> clazz) {
	
		return EmployeeModel.class.equals(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		EmployeeModel empmodel=(EmployeeModel)obj;
		//errors.rejectValue("empmail","emp.empmail");
		//ValidationUtils.rejectIfEmpty(errors,"empmail","emp.email.empty");
		
		
		//ValidationUtils.rejectIfEmpty(errors,"empName",  "emp.empName.notempty");
		if(empmodel.getEmpName().isEmpty()) {
			System.out.println("am in name");
			errors.rejectValue("empName","emp.name");
		}
		if(empmodel.getEmpmail().indexOf("@")==-1) {
			System.out.println("am in mail");
			errors.rejectValue("empmail","emp.email.empty");
		}
		
	}

}
