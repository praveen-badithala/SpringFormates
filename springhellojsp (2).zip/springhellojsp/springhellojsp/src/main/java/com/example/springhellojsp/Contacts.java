package com.example.springhellojsp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="new_employee")

public class Contacts implements Serializable {
	
	
	private static final long serialVersionUID = 6214444020342657797L;
	private Long eventId;
	private Timestamp tmsCreate; 
	private Timestamp tmsUpdate;
	private String agentCreate;
	private String agentUpdate;
	private String profilId;
	private String clientId;
	public Long getEventId() {
		return eventId;
	}
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}
	public Timestamp getTmsCreate() {
		return tmsCreate;
	}
	public void setTmsCreate(Timestamp tmsCreate) {
		this.tmsCreate = tmsCreate;
	}
	public Timestamp getTmsUpdate() {
		return tmsUpdate;
	}
	public void setTmsUpdate(Timestamp tmsUpdate) {
		this.tmsUpdate = tmsUpdate;
	}
	public String getAgentCreate() {
		return agentCreate;
	}
	public void setAgentCreate(String agentCreate) {
		this.agentCreate = agentCreate;
	}
	public String getAgentUpdate() {
		return agentUpdate;
	}
	public void setAgentUpdate(String agentUpdate) {
		this.agentUpdate = agentUpdate;
	}
	public String getProfilId() {
		return profilId;
	}
	public void setProfilId(String profilId) {
		this.profilId = profilId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
