package com.example.springhellojsp.test;

public class Car implements Comparable<Car> {

	String carName;
	int carNO;
	@Override
	public int compareTo(Car newcar) {
	    if(this.carNO<newcar.carNO) {
	    	return -1;
	    }else if(this.carNO>newcar.carNO) {
	    	return 1;
	    }else {
	    	return 0;
	    }
		
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public int getCarNO() {
		return carNO;
	}
	public void setCarNO(int carNO) {
		this.carNO = carNO;
	}
	@Override
	public String toString() {
		return "Car [carName=" + carName + ", carNO=" + carNO + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + carNO;
		result = prime * result + ((carName == null) ? 0 : carName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		Car car=(Car)obj;
		if(obj==null) {
			return false;
		}
		if(getClass()!=obj.getClass()) {
			return false;
		}
		
		if(this.carNO==car.getCarNO() && this.getCarName()== car.getCarName()) {
			System.out.println("car NO>>>"+this.carNO+"====="+car.getCarNO());
			System.out.println("car name>>>"+this.carName+"====="+car.getCarName());
			return true;
		}
		
		return true;
	}
	
	
	
	
	
	
}
