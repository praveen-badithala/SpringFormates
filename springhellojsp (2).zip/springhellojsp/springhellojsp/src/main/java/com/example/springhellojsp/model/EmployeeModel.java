package com.example.springhellojsp.model;

import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;
@Component
public class EmployeeModel {
	
	private int empID;
	private String empName;
	private String  empmail;
	private Date empdob;
	private String empdoj;
	private String  gender;
	private String country;
	private String[] languages;
	private String[] favColor;
	private String empaddress;
	private int department;
	private String plocation;
	private Communication communication;
	private List<PreviousEmpAddress> previousaddressList;
	public EmployeeModel() {
		
		System.out.println("am in EmployeeModel constructor>>>>>");
	}
	@PostConstruct
	public void init() {
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>am init of EmployeeModel"+this.getEmpmail());
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>am in destroy of EmployeeModel");
	}
	
	
	
	
	
	

	
	public List<PreviousEmpAddress> getPreviousaddressList() {
		return previousaddressList;
	}
	public void setPreviousaddressList(List<PreviousEmpAddress> previousaddressList) {
		this.previousaddressList = previousaddressList;
	}
	public Communication getCommunication() {
		return communication;
	}
	public void setCommunication(Communication communication) {
		this.communication = communication;
	}
	public String getPlocation() {
		return plocation;
	}
	public void setPlocation(String plocation) {
		this.plocation = plocation;
	}
	public int getDepartment() {
		return department;
	}
	public void setDepartment(int department) {
		this.department = department;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	
	public String getEmpaddress() {
		return empaddress;
	}
	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}
	public String[] getFavColor() {
		return favColor;
	}
	public void setFavColor(String[] favColor) {
		this.favColor = favColor;
	}
	public String[] getLanguages() {
		return languages;
	}
	public void setLanguages(String[] languages) {
		this.languages = languages;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpmail() {
		return empmail;
	}
	public void setEmpmail(String empmail) {
		this.empmail = empmail;
	}
	
	public Date getEmpdob() {
		return empdob;
	}
	public void setEmpdob(Date empdob) {
		this.empdob = empdob;
	}
	public String getEmpdoj() {
		return empdoj;
	}
	public void setEmpdoj(String empdoj) {
		this.empdoj = empdoj;
	}
	
	
	
	
	
	

}
