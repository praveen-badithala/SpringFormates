package com.example.springhellojsp.formatters;

import java.text.ParseException;
import java.util.Locale;

import org.springframework.format.Formatter;

import com.example.springhellojsp.model.Phone;

public class PhoneFormatter implements Formatter<Phone>{

	@Override
	public String print(Phone phone, Locale locale) {
		Integer countryode=phone.getCountryCode();
		Long landlineNumber=phone.getLandLineNumber();
		String value=countryode+"-"+landlineNumber;
		System.out.println("am in print"+value);
		return value;
	}

	@Override
	public Phone parse(String landlineString, Locale locale) throws ParseException {
		Phone phone=new Phone();
		phone.setCountryCode(Integer.parseInt(landlineString.split("-")[0]));
		phone.setCountryCode(Integer.parseInt(landlineString.split("-")[1]));
		return phone;
	}

	

}
