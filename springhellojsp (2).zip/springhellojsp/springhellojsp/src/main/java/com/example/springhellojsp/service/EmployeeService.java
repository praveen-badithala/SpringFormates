/**
 * 
 */
package com.example.springhellojsp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springhellojsp.entity.DepartMent;
import com.example.springhellojsp.entity.EmployeeEntity;

/**
 * @author praveen
 *
 */
@Service
public interface EmployeeService {

	public void saveEmp(EmployeeEntity emp);
	public List<DepartMent> loaddepartmentlist(String deptname);
	public List<EmployeeEntity> getemplist();
	public EmployeeEntity loadById(int empid) ;
}
