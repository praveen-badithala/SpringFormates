package com.example.springhellojsp.model;

public class PreviousEmpAddress {
	
	private String stateName;
	private String address;
	private int pinCode;
	
	PreviousEmpAddress(){
		
	}
	
	
	public PreviousEmpAddress(String stateName, String address, int pinCode) {
		
		this.stateName = stateName;
		this.address = address;
		this.pinCode = pinCode;
	}


	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	
	

}
