package com.example.springhellojsp.exception;

public class DepartMentNotFoundException extends RuntimeException {
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -1052607721597744231L;

	public DepartMentNotFoundException(String msg) {
	  super(msg);	
	}

}
