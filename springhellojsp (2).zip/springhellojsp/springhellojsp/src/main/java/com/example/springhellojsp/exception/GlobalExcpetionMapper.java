package com.example.springhellojsp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExcpetionMapper {
  
	/*@ExceptionHandler(value=DepartMentNotFoundException.class)
	public ResponseEntity<Object> departmentnotFoundExeption(){
		return new ResponseEntity<>("Deprtment Not FoundException",HttpStatus.NOT_FOUND);
	}*/
	
	@ExceptionHandler(value=DepartMentNotFoundException.class)
	public String departmentnotFndExeption(Model model){
		model.addAttribute("errormsg","Deprtment Not Found Exception");
		model.addAttribute("cause","Please Select ProperDepartment");
		return "LoginException";
	}
}
