package com.example.springhellojsp.model;

public class Phone {
 private Integer countryCode;
 private Long landLineNumber;
 
 
public Integer getCountryCode() {
	return countryCode;
}
public void setCountryCode(Integer countryCode) {
	this.countryCode = countryCode;
}
public Long getLandLineNumber() {
	return landLineNumber;
}
public void setLandLineNumber(Long landLineNumber) {
	this.landLineNumber = landLineNumber;
}
 
 
}
