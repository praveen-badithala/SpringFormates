package com.example.springhellojsp.postprocessor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import com.example.springhellojsp.model.EmployeeModel;

@Component
public class MyBeanIntializationProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		if(beanName.equals("employeeModel")) {
			EmployeeModel model=(EmployeeModel)bean;
			model.setEmpmail("getset123.com");
			System.out.println("#####################################################>>>>"+beanName);
		}
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		if(beanName.equals("employeeModel")) {
			EmployeeModel model=(EmployeeModel)bean;
			model.setEmpmail("getset.com");
			System.out.println("#####################################################>>>>postProcessAfterInitialization"+beanName);
		}
		return bean;
	}
	
	

}
