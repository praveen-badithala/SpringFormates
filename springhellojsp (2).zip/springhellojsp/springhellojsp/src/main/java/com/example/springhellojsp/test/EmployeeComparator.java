package com.example.springhellojsp.test;
//comparator example

import java.util.Comparator;

import com.example.springhellojsp.entity.EmployeeEntity;

public class EmployeeComparator implements Comparator<EmployeeEntity> {

	@Override
	public int compare(EmployeeEntity obj1, EmployeeEntity obj2) {
		EmployeeEntity emp1=(EmployeeEntity)obj1;
		EmployeeEntity emp2=(EmployeeEntity)obj2;
		if(emp2.getEmpID()%2==0 && emp1.getEmpID()%2!=0){
			
			return 1;
		}else if(emp1.getEmpID()%2!=0 && emp2.getEmpID()%2!=0) {
			if(emp2.getEmpID()>emp1.getEmpID()) {
				return 1;
			}else if(emp2.getEmpID()<emp1.getEmpID()) {
				return -1;
			}else {
				return 0;
			}
		   
		}else if(emp2.getEmpID()%2==0 && emp1.getEmpID()%2==0) {
			if(emp2.getEmpID()>emp1.getEmpID()) {
				return 1;
			}else if(emp2.getEmpID()<emp1.getEmpID()) {
				return -1;
			}else {
				return 0;
			}
		}else if(emp2.getEmpID()%2!=0 && emp1.getEmpID()%2==0){
		return -1;	
		}
		return 0;
	}
   

}
