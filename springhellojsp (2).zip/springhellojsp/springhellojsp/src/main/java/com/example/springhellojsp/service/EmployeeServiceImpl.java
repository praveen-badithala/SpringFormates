package com.example.springhellojsp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springhellojsp.dao.EmployeeDao;
import com.example.springhellojsp.entity.DepartMent;
import com.example.springhellojsp.entity.EmployeeEntity;
import com.example.springhellojsp.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao empdao;
	@Override
	public void saveEmp(EmployeeEntity emp) {
		empdao.saveEmp(emp);
	}
	
	public List<DepartMent> loaddepartmentlist(String deptname){
		
		return empdao.loaddepartmentlist(deptname);
	}

	@Override
	public List<EmployeeEntity> getemplist() {
		
		return empdao.getemplist();
	}

	@Override
	public EmployeeEntity loadById(int empid) {
		
		return empdao.loadById(empid);
	}

}
