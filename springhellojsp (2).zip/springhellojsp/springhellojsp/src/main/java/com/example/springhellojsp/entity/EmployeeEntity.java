package com.example.springhellojsp.entity;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author praveen
 *
 */
@Entity
@Table(name="dept_emp_master")
public class EmployeeEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="dept_emp_master_generator")
	@SequenceGenerator(name="dept_emp_master_generator",initialValue=1,allocationSize=1,sequenceName="dept_emp_master_sequense")
	@Column(name="emp_id")
	private int empID;
	@Column(name="emp_name",nullable=false,length=25)
	private String empName;
	@Column(name="emp_sal",nullable=false,length=150)
	private double empsal;
	@Column(name="emp_dob",nullable=true)
	private Date empdoj;
	@Column(name="emp_doj",nullable=true)
	private Date empdobj;
	@Column(name="gender")
	private String gender;
	@Column(name="country",length=10)
	private String country;
	@Column(name="languages",length=8)
	private String[] languages;
	@Column(name="fav_colors",length=12)
	private String[] favColor;
	@Column(name="emp_address")
	private String empaddress;
	@Column(name="dept_id")
	private int  deptmaster;
	@Column(name="prefered_location")
	private String plocations;
	

	
	
	public String getPlocations() {
		return plocations;
	}
	public void setPlocations(String plocations) {
		this.plocations = plocations;
	}
	public int getDeptmaster() {
		return deptmaster;
	}
	public void setDeptmaster(int deptmaster) {
		this.deptmaster = deptmaster;
	}
	public String getEmpaddress() {
		return empaddress;
	}
	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}
	public String[] getFavColor() {
		return favColor;
	}
	public void setFavColor(String[] favColor) {
		this.favColor = favColor;
	}
	public String[] getLanguages() {
		return languages;
	}
	public void setLanguages(String[] languages) {
		this.languages = languages;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpsal() {
		return empsal;
	}
	public void setEmpsal(double empsal) {
		this.empsal = empsal;
	}
	public Date getEmpdoj() {
		return empdoj;
	}
	public void setEmpdoj(Date empdoj) {
		this.empdoj = empdoj;
	}
	public Date getEmpdobj() {
		return empdobj;
	}
	public void setEmpdobj(Date empdobj) {
		this.empdobj = empdobj;
	}
	@Override
	public String toString() {
		return "EmployeeEntity [empID=" + empID + ", empName=" + empName + ", empsal=" + empsal + ", empdoj=" + empdoj
				+ ", empdobj=" + empdobj + ", gender=" + gender + ", country=" + country + ", languages="
				+ Arrays.toString(languages) + ", favColor=" + Arrays.toString(favColor) + ", empaddress=" + empaddress
				+ ", deptmaster=" + deptmaster + ", plocations=" + plocations + "]";
	}
	
	
	
	
	

}
