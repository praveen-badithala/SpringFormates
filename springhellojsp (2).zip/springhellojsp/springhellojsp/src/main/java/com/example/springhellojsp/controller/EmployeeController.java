package com.example.springhellojsp.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.springhellojsp.entity.DepartMent;
import com.example.springhellojsp.entity.EmployeeEntity;
import com.example.springhellojsp.exception.DepartMentNotFoundException;
import com.example.springhellojsp.model.Communication;
import com.example.springhellojsp.model.EmployeeModel;
import com.example.springhellojsp.model.Phone;
import com.example.springhellojsp.model.PreviousEmpAddress;
import com.example.springhellojsp.service.EmployeeService;
import com.example.springhellojsp.validator.EmployeeValidator;

@Controller
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empservice;
	
	@Autowired
	private EmployeeValidator empvalidator;
	
   @InitBinder
	public void validationBinder(WebDataBinder binder) {
		binder.addValidators(empvalidator);
	}
   @InitBinder
   public void initBinder(WebDataBinder binder) {
       SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
       dateFormat.setLenient(false);
       binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
   }
	
	@GetMapping("/load")
	public String loadajaxpage() {
		System.out.println("am in");
		return "index";
	}
	
	@GetMapping("/loademplist")
	public String loademplist(Model model) {
		List<EmployeeEntity> empentitylist=empservice.getemplist();
		model.addAttribute("emplist",empentitylist);
		return "EmployeeList";
	}
	
	@GetMapping("/register")
	public String loadRegistartionPage(Model model) {
		EmployeeModel regmodel=new EmployeeModel();
		String[] favcolors= {"green","white","red","yellow"};
		regmodel.setFavColor(favcolors);
		Phone phone=new Phone();
		phone.setCountryCode(400);
		long value=123456;
		phone.setLandLineNumber(value);
		Communication communication=new Communication();
		communication.setPhone(phone);
		regmodel.setCommunication(communication);
		List previousaddressList=new ArrayList();
		PreviousEmpAddress address1=new PreviousEmpAddress("Telangana","Ameerpeta",1056156);
		PreviousEmpAddress address2=new PreviousEmpAddress("AndraPradsh","jaganNagara",56895652);
		PreviousEmpAddress address3=new PreviousEmpAddress("TamilNadu","palaniswami",8987552);
		
		previousaddressList.add(address1);
		previousaddressList.add(address2);
		previousaddressList.add(address3);
		
		regmodel.setPreviousaddressList(previousaddressList);
		model.addAttribute("regemp",regmodel);
		
		return "EmployeeRegistrationForm";
		
	}
	
	@PostMapping("/saveemp")
	public String saveEmp(@ModelAttribute("regemp") @Validated EmployeeModel empmodel,BindingResult errors) {
		System.out.println("am in regemp>>>>>>"+empmodel.getPreviousaddressList().get(0).getPinCode());
		if(errors.hasErrors()) {
			System.out.println("am in regemp>>>>>>123");
			return "EmployeeRegistrationForm";
		}
		EmployeeEntity emp=new EmployeeEntity();
		emp.setEmpName(empmodel.getEmpName());
		emp.setEmpsal(55000);
		emp.setGender(empmodel.getGender());
		emp.setCountry(empmodel.getCountry());
		emp.setLanguages(empmodel.getLanguages());
		emp.setFavColor(empmodel.getFavColor());
		emp.setEmpaddress(empmodel.getEmpaddress());
		if(empmodel.getDepartment()==0) {
			throw new DepartMentNotFoundException("Unable To Find Department");
		}else {
			emp.setDeptmaster(empmodel.getDepartment());
		}
		System.out.println("empmodel.commnication>>>>"+empmodel.getCommunication().getMobileNo()+"==="+empmodel.getCommunication().getPhone().getCountryCode());
		emp.setEmpID(empmodel.getEmpID());
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		String strempdoj=empmodel.getEmpdoj();
		Date dob=empmodel.getEmpdob();
		emp.setPlocations(empmodel.getPlocation());
		//System.out.println("dob>>>>>>>>"+dob);
		
		try {
			
			emp.setEmpdoj(new Date());
			emp.setEmpdobj(dob);
		} catch (Exception e) {
			e.printStackTrace();
		}
		empservice.saveEmp(emp);
		return "redirect:/emp/loademplist";
	}
	
	 @RequestMapping(method = RequestMethod.POST)
	 public @ResponseBody List<DepartMent> add(HttpServletRequest request, HttpServletResponse response)
				throws Exception {
		 String deptname=request.getParameter("deptname");
		 System.out.println("84>>>>>>"+deptname);
           return empservice.loaddepartmentlist(deptname);
	 }
	 
	 
	// @RequestMapping(method=RequestMethod.GET)
	 //public ModelAndView loadbyId(@RequestParam("empid") int empid) {
	   public ModelAndView loadbyId() {
		 System.out.println("empid<<<<<<");
		 int empid=2;
		 ModelAndView model=new ModelAndView();
		 EmployeeEntity entity= empservice.loadById(empid);
		 model.addObject("regemp", entity);
		 model.setViewName("EmployeeRegistrationForm");
		// return "EmployeeRegistrationForm";
		 return model;
		  
	 }
	 
	@GetMapping("/loadbyid")
	 public String loadbyId(@RequestParam("empid") int empid,Model model) {
	 //  public String loadbyIdnew(Model model) {
		 System.out.println("entity<<<<<<<<<<<"+empid);
		 EmployeeEntity entity= empservice.loadById(empid);
		 System.out.println("entity<<<<<<<<<<<"+entity.getEmpName());
		 EmployeeModel empmodel=new EmployeeModel();
		 empmodel.setCountry(entity.getCountry());
		 empmodel.setDepartment(entity.getDeptmaster());
		 empmodel.setEmpaddress(entity.getEmpaddress());
		 empmodel.setEmpdob(entity.getEmpdobj());
		 empmodel.setEmpdoj(entity.getEmpdoj().toString());
		 empmodel.setEmpmail(entity.getEmpName());
		 empmodel.setEmpName(entity.getEmpName());
		 if(entity.getFavColor()!=null) {
			 empmodel.setFavColor(entity.getFavColor());
		 }else {
			 String[] favcolors= {"green","white","red","yellow"};
				
			 empmodel.setFavColor(favcolors);
		 }
		 empmodel.setGender(entity.getGender());
		 empmodel.setLanguages(entity.getLanguages());
		 empmodel.setEmpID(entity.getEmpID());
		 empmodel.setPlocation(entity.getPlocations());
		 model.addAttribute("regemp", empmodel);
		 
		// return "EmployeeRegistrationForm";
		 return "EmployeeRegistrationForm";
		  
	 }
	
	@ModelAttribute("favcolors")//alternate for referencedata
	public List<String> referenceData(){
		System.out.println("am in favcolors>>>>>>>>>>>>>>>");
		List<String> favcolors=new ArrayList();
		
		favcolors.add("white");favcolors.add("yellow");
		favcolors.add("red");
		favcolors.add("green");
		
		return favcolors;
	}
	
	@ModelAttribute("plocations")//alternate for referencedata
	public List<String> plocations(){
		System.out.println("am in plocations>>>>>>>>>>>>>>>");
		List<String> plocation=new ArrayList();
		
		plocation.add("Hyderabad");plocation.add("Banglore");
		plocation.add("Mumbai");
		plocation.add("Pune");
		
		return plocation;
	}
	
	@ExceptionHandler(ArithmeticException.class)
	public String exceptionMapper(Model model) {
		model.addAttribute("errormsg","Sorry for the inconvience Plase Use Below Button");
		return "LoginException";
	}
	
	@ExceptionHandler(NullPointerException.class)
	public String nullPointerexceptionMapper(Model model) {
		model.addAttribute("errormsg","Sorry for the inconvience Plase Use Below Button");
		return "LoginException";
	}
	 
	
}
